<!-- call action area start  -->
<section id="call-action" class="call-action">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xxl-6 col-xl-7 col-lg-8 col-md-9">
                <div class="inner-content">
                    <h2>We love to make perfect <br>solutions for your business</h2>
                    <p>
                        Why I say old chap that is, spiffing off his nut cor blimey
                        guvnords geeza<br>
                        bloke knees up bobby, sloshed arse William cack Richard. Bloke
                        fanny around chesed of bum bag old lost the pilot say there
                        spiffing off his nut.
                    </p>
                    <div class="light-rounded-buttons">
                        <a href="javascript:void(0)" class="btn primary-btn-outline">Get Started</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- call action area end  -->